#include "hooks.h"
#include "memory.h"
#include <cstring>

extern pid_t g_targetPid;

void Hooks::InstallAll() {
    uint8_t retBytes[] = {0xD6, 0x5F, 0x03, 0xC0};
    uintptr_t addr = Memory::FindPattern(g_targetPid, (uint8_t*)"\x00\x00\x00\x00", 4, "xxxx");
    if (addr) {
        Memory::WriteMemory(g_targetPid, (void*)addr, retBytes, 4);
    }

    uint8_t nopBytes[] = {0x1F, 0x20, 0x03, 0xD5};
    uintptr_t analyticsAddr = Memory::FindPattern(g_targetPid, (uint8_t*)"\x01\x00\x00\x14", 4, "xxxx");
    if (analyticsAddr) {
        Memory::WriteMemory(g_targetPid, (void*)analyticsAddr, nopBytes, 4);
    }

    uintptr_t tagsAddr = Memory::FindPattern(g_targetPid, (uint8_t*)"\x74\x65\x73\x74", 4, "xxxx");
    if (tagsAddr) {
        uint8_t fakeTags[] = {'r','e','l','e','a','s','e','\0'};
        Memory::WriteMemory(g_targetPid, (void*)tagsAddr, fakeTags, 7);
    }
}