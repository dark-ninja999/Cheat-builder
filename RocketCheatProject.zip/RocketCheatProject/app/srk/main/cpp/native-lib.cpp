#include <jni.h>
#include <android/log.h>
#include <thread>
#include <atomic>
#include "cheat_engine.h"
#include "memory.h"
#include "hooks.h"

#define LOG_TAG "ROCKET_CHEAT"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

std::atomic<bool> g_cheatActive{false};
std::atomic<bool> g_wallhack{false};
std::atomic<bool> g_aimbot{false};
std::atomic<bool> g_antirecoil{false};

extern "C" {

JNIEXPORT void JNICALL
Java_com_rocket_cheat_InjectorNative_setCheatState(JNIEnv *env, jobject thiz, jboolean state) {
    g_cheatActive = state;
    LOGI("Cheat state: %d", state);
}

JNIEXPORT void JNICALL
Java_com_rocket_cheat_InjectorNative_toggleWallhack(JNIEnv *env, jobject thiz, jboolean enable) {
    g_wallhack = enable;
    if (enable) CheatEngine::EnableWallhack();
    else CheatEngine::DisableWallhack();
    LOGI("Wallhack: %d", enable);
}

JNIEXPORT void JNICALL
Java_com_rocket_cheat_InjectorNative_toggleAimbot(JNIEnv *env, jobject thiz, jboolean enable) {
    g_aimbot = enable;
    LOGI("Aimbot: %d", enable);
}

JNIEXPORT void JNICALL
Java_com_rocket_cheat_InjectorNative_toggleAntiRecoil(JNIEnv *env, jobject thiz, jboolean enable) {
    g_antirecoil = enable;
    LOGI("AntiRecoil: %d", enable);
}

JNIEXPORT jboolean JNICALL
Java_com_rocket_cheat_InjectorNative_injectCheat(JNIEnv *env, jobject thiz, jstring packageName) {
    const char *pkg = env->GetStringUTFChars(packageName, nullptr);
    pid_t pid = Memory::FindProcess(pkg);
    env->ReleaseStringUTFChars(packageName, pkg);
    if (pid <= 0) {
        LOGI("Process not found");
        return JNI_FALSE;
    }
    LOGI("Found PID: %d", pid);
    if (!Memory::AttachToProcess(pid)) {
        LOGI("Attach failed");
        return JNI_FALSE;
    }
    Hooks::InstallAll();
    std::thread([](){
        while (g_cheatActive) {
            if (g_aimbot) CheatEngine::RunAimbot();
            if (g_antirecoil) CheatEngine::RunAntiRecoil();
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
    }).detach();
    return JNI_TRUE;
}

} // extern "C"