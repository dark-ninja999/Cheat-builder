#include "cheat_engine.h"
#include <dlfcn.h>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

struct Vector3 { float x, y, z; };
struct Quaternion { float x, y, z, w; };
struct Player { void* obj; Vector3 pos; Vector3 headPos; bool isEnemy; };

static void* (*get_main_camera)() = nullptr;
static void* (*find_objects_of_type)(const char*) = nullptr;
static Vector3 (*world_to_screen)(Vector3 worldPos) = nullptr;
static void (*set_rotation)(void* camera, Quaternion rot) = nullptr;
static float* (*get_recoil_ptr)(void* weapon) = nullptr;

namespace CheatEngine {

static vector<Player> GetValidPlayers() {
    vector<Player> result;
    void* playerList = find_objects_of_type("PlayerController");
    if (!playerList) return result;
    uintptr_t arrBase = *(uintptr_t*)((char*)playerList + 0x8);
    int count = *(int*)((char*)playerList + 0x10);
    for (int i = 0; i < count && i < 32; ++i) {
        Player p;
        p.obj = *(void**)(arrBase + i * 0x8);
        if (!p.obj) continue;
        p.pos = *(Vector3*)((char*)p.obj + 0x2C);
        p.headPos = *(Vector3*)((char*)p.obj + 0x50);
        int team = *(int*)((char*)p.obj + 0x68);
        int localTeam = *(int*)((char*)find_objects_of_type("LocalPlayer") + 0x68);
        p.isEnemy = (team != localTeam);
        result.push_back(p);
    }
    return result;
}

static Vector3 WorldToScreen(Vector3 world) {
    if (!world_to_screen) return {0,0,0};
    return world_to_screen(world);
}

static Quaternion LookRotation(Vector3 from, Vector3 to) {
    Vector3 dir = {to.x - from.x, to.y - from.y, to.z - from.z};
    float len = sqrt(dir.x*dir.x + dir.y*dir.y + dir.z*dir.z);
    if (len < 0.001f) return {0,0,0,1};
    dir.x /= len; dir.y /= len; dir.z /= len;
    Quaternion q;
    float cosHalf = sqrt((1 + dir.z) / 2);
    float sinHalf = sqrt((1 - dir.z) / 2);
    q.x = -dir.y * sinHalf;
    q.y = dir.x * sinHalf;
    q.z = 0;
    q.w = cosHalf;
    return q;
}

void EnableWallhack() {
    auto players = GetValidPlayers();
    for (auto &p : players) {
        if (!p.isEnemy) continue;
        void* rend = *(void**)((char*)p.obj + 0x30);
        if (rend) {
            *(int*)((char*)rend + 0x54) = 3;
            *(int*)((char*)rend + 0x58) = 0;
        }
    }
}

void DisableWallhack() {
    auto players = GetValidPlayers();
    for (auto &p : players) {
        void* rend = *(void**)((char*)p.obj + 0x30);
        if (rend) {
            *(int*)((char*)rend + 0x54) = 1;
            *(int*)((char*)rend + 0x58) = 4;
        }
    }
}

void RunAimbot() {
    auto players = GetValidPlayers();
    if (players.empty()) return;
    Player target;
    float minDist = 1e9f;
    for (auto &p : players) {
        if (!p.isEnemy) continue;
        Vector3 screen = WorldToScreen(p.headPos);
        float dist = sqrt((screen.x - 0.5f)*(screen.x - 0.5f) + (screen.y - 0.5f)*(screen.y - 0.5f));
        if (dist < minDist) {
            minDist = dist;
            target = p;
        }
    }
    if (minDist > 0.25f) return;
    void* cam = get_main_camera();
    if (!cam) return;
    Vector3 camPos = *(Vector3*)((char*)cam + 0x2C);
    Quaternion targetRot = LookRotation(camPos, target.headPos);
    Quaternion curRot = *(Quaternion*)((char*)cam + 0x38);
    curRot.x += (targetRot.x - curRot.x) * 0.3f;
    curRot.y += (targetRot.y - curRot.y) * 0.3f;
    curRot.z += (targetRot.z - curRot.z) * 0.3f;
    curRot.w += (targetRot.w - curRot.w) * 0.3f;
    set_rotation(cam, curRot);
}

void RunAntiRecoil() {
    void* weapon = find_objects_of_type("Weapon");
    if (!weapon) return;
    float* recoil = get_recoil_ptr(weapon);
    if (recoil) {
        recoil[0] = 0.0f;
        recoil[1] = 0.0f;
    }
}

void InitPointers() {
    void* handle = dlopen("libil2cpp.so", RTLD_LAZY);
    if (!handle) return;
    get_main_camera = (void*(*)())dlsym(handle, "UnityEngine_Camera_get_main");
    find_objects_of_type = (void*(*)(const char*))dlsym(handle, "UnityEngine_Object_FindObjectOfType_Type");
    world_to_screen = (Vector3(*)(Vector3))dlsym(handle, "UnityEngine_Camera_WorldToScreenPoint");
    set_rotation = (void(*)(void*, Quaternion))dlsym(handle, "UnityEngine_Transform_set_rotation");
    get_recoil_ptr = (float*(*)(void*))dlsym(handle, "Weapon_get_recoilOffset");
}

} // namespace CheatEngine