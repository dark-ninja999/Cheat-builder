#include "memory.h"
#include <fstream>
#include <sstream>
#include <cstring>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <errno.h>

pid_t Memory::FindProcess(const char* pkg) {
    for (int pid = 100; pid < 30000; ++pid) {
        std::string path = "/proc/" + std::to_string(pid) + "/cmdline";
        std::ifstream f(path);
        std::string line;
        if (std::getline(f, line)) {
            if (line.find(pkg) != std::string::npos) {
                return pid;
            }
        }
    }
    return -1;
}

bool Memory::AttachToProcess(pid_t pid) {
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) == -1)
        return false;
    int status;
    waitpid(pid, &status, 0);
    return true;
}

bool Memory::WriteMemory(pid_t pid, void* addr, const void* data, size_t len) {
    for (size_t i = 0; i < len; i += sizeof(long)) {
        long word = 0;
        memcpy(&word, (char*)data + i, std::min(sizeof(long), len - i));
        if (ptrace(PTRACE_POKEDATA, pid, (void*)((uintptr_t)addr + i), (void*)word) == -1)
            return false;
    }
    return true;
}

bool Memory::ReadMemory(pid_t pid, void* addr, void* out, size_t len) {
    for (size_t i = 0; i < len; i += sizeof(long)) {
        long word = ptrace(PTRACE_PEEKDATA, pid, (void*)((uintptr_t)addr + i), nullptr);
        if (word == -1 && errno) return false;
        memcpy((char*)out + i, &word, std::min(sizeof(long), len - i));
    }
    return true;
}

uintptr_t Memory::FindPattern(pid_t pid, const uint8_t* pattern, size_t len, const char* mask) {
    std::ifstream maps("/proc/" + std::to_string(pid) + "/maps");
    std::string line;
    while (std::getline(maps, line)) {
        if (line.find("libil2cpp.so") == std::string::npos) continue;
        size_t dash = line.find('-');
        uintptr_t start = strtoul(line.substr(0, dash).c_str(), nullptr, 16);
        uintptr_t end = strtoul(line.substr(dash+1, line.find(' ')-dash-1).c_str(), nullptr, 16);
        for (uintptr_t p = start; p < end - len; ++p) {
            bool found = true;
            for (size_t i = 0; i < len; ++i) {
                if (mask[i] == 'x') continue;
                uint8_t byte;
                ReadMemory(pid, (void*)(p+i), &byte, 1);
                if (byte != pattern[i]) { found = false; break; }
            }
            if (found) return p;
        }
    }
    return 0;
}