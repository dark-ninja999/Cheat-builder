package com.rocket.cheat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.btnInject);
        btn.setOnClickListener(v -> {
            boolean ok = InjectorNative.injectCheat("com.standoff2");
            if (ok) {
                Toast.makeText(this, "Внедрено!", Toast.LENGTH_SHORT).show();
                startService(new Intent(this, OverlayService.class));
            } else {
                Toast.makeText(this, "Ошибка: игра не запущена", Toast.LENGTH_SHORT).show();
            }
        });
    }
}