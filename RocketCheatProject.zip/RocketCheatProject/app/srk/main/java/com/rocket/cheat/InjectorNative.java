package com.rocket.cheat;

public class InjectorNative {
    static { System.loadLibrary("cheat"); }
    public static native void setCheatState(boolean state);
    public static native void toggleWallhack(boolean enable);
    public static native void toggleAimbot(boolean enable);
    public static native void toggleAntiRecoil(boolean enable);
    public static native boolean injectCheat(String packageName);
}