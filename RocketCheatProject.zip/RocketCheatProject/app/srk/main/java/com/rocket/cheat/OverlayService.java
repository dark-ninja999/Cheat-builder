package com.rocket.cheat;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout layout;
    private boolean wall = false, aim = false, recoil = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0x88000000);

        Button btnWall = createToggle("СТЕНЫ", () -> { wall = !wall; InjectorNative.toggleWallhack(wall); });
        Button btnAim = createToggle("АИМ", () -> { aim = !aim; InjectorNative.toggleAimbot(aim); });
        Button btnRecoil = createToggle("ОТДАЧА", () -> { recoil = !recoil; InjectorNative.toggleAntiRecoil(recoil); });

        layout.addView(btnWall);
        layout.addView(btnAim);
        layout.addView(btnRecoil);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 50; params.y = 200;
        wm.addView(layout, params);

        SharedPreferences prefs = getSharedPreferences("cheat_cfg", MODE_PRIVATE);
        wall = prefs.getBoolean("wall", false);
        aim = prefs.getBoolean("aim", false);
        recoil = prefs.getBoolean("recoil", false);
        updateButtons();
    }

    private Button createToggle(String label, Runnable action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setPadding(20, 10, 20, 10);
        btn.setOnClickListener(v -> {
            action.run();
            Toast.makeText(this, label + (wall||aim||recoil ? " ON" : " OFF"), Toast.LENGTH_SHORT).show();
            saveState();
        });
        return btn;
    }

    private void updateButtons() {
        for (int i = 0; i < layout.getChildCount(); i++) {
            View v = layout.getChildAt(i);
            if (v instanceof Button) {
                boolean state = (i == 0 && wall) || (i == 1 && aim) || (i == 2 && recoil);
                v.setBackgroundColor(state ? 0xFF00CC00 : 0xFFCC0000);
            }
        }
    }

    private void saveState() {
        getSharedPreferences("cheat_cfg", MODE_PRIVATE).edit()
                .putBoolean("wall", wall)
                .putBoolean("aim", aim)
                .putBoolean("recoil", recoil)
                .apply();
        updateButtons();
    }

    @Override
    public void onDestroy() {
        if (wm != null && layout != null) wm.removeView(layout);
        super.onDestroy();
    }
}